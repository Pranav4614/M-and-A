# Archived v2 snapshot

These files describe the project as of v2 (4 admitted rows, Chevron–Noble held for review, 30 tests). They are kept for
history only and are **superseded** by `docs/validation_v3.md` and `reports/benchmark_result.json` (5 admitted rows, 40 tests).
Numbers in these files are intentionally not updated.
