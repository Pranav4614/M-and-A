# Accuracy and credibility improvements — 23 October 2026

## Result
**No real-data model was fitted. Predictive accuracy remains unknown.** The current real research seed has 6 candidate observations; 4 pass all primary cohort, label-evidence, revenue, currency, and feature checks. The training command intentionally exits with the blocked-before-fit status until the approved sample and time-validation design are large enough.

## Improvements implemented in this pass

1. **Stricter label-to-evidence binding.** The synergy quote must mention the claim amount, annual period, and cost/expense wording. The separate pre-tax evidence quote must explicitly say pre-tax and contain the same dollar amount. Strict tax-basis evidence and the announced-claim source must be SEC filing/exhibit evidence.
2. **Financial-input control.** Acquirer and target revenue source URLs must be SEC filings, and both filing dates must precede the deal announcement. Every synergy and revenue input is explicitly labeled USD (USD millions in numeric fields); non-USD values are blocked pending documented conversion.
3. **Cohort protection.** Both parties must be US-exchange-listed at announcement, the deal must fit the non-financial public-to-public rule, ranges/lower bounds are not converted into points, and duplicate transactions are checked regardless of party order.
4. **Chronological evaluation.** Whole announcement years stay together. The selection plan uses expanding-window temporal folds, then a separate calibration period and untouched future test. The median baseline remains mandatory; Ridge, median Quantile Regression (MAE-aligned), and Huber are restrained candidate regressors, not an algorithm competition with a large hyperparameter search.
5. **Simplicity preference.** One-standard-error selection is used as a complexity preference, not an inferential confidence interval. A model is not claimed to improve accuracy unless it beats the median baseline on the future test.
6. **Category support.** Cash has 0 eligible observations, stock has 1, and mixed has 3. Cash predictions are unsupported; stock/mixed effects are too sparse for reliable interpretation. `payment_method_support_audit.csv` reports this explicitly.
7. **Stale-artifact protection.** The prediction CLI only permits an inference if a current successful evaluation exists, the model metadata hashes match that evaluation, and the run is positively marked as real-data (not a synthetic mechanics fixture). It rejects unsupported payment classes and flags numeric extrapolation/low-support categories.
8. **Reproducibility.** Every run captures UTC timestamp, Python/pandas/NumPy/scikit-learn versions, input SHA-256, and training-script SHA-256.
9. **Tests.** The full suite passes **28 tests** covering label/feature evidence, tax-basis amount matching, currency, listing-time scope, duplicate rows, temporal grouping, simple-model selection, category coverage, prediction input validation, and stale/synthetic-artifact rejection.
10. **Mechanics smoke test.** The dual-target training functions were exercised on a disposable 126-row artificial fixture; all expected output files were produced and deleted with the temporary directory. No resulting score, fitted model, or synthetic observation was saved to the research package or used as a project result.
11. **Inference interface.** `predict_synergy.py` returns `MODEL_NOT_AVAILABLE` on the current blocked run and refuses stale artifacts, input-hash mismatches, un-attested data, and payment categories absent from the model-development rows.

## Current source/data gate

- Input candidate rows in strict seed ledger: **6**
- Cohort eligible: **5**
- Strict label-evidence ready: **5**
- Full primary feature-ready: **4**
- Target-only diagnostic-ready: **5**
- Current primary payment-method counts: **mixed 3, stock 1, cash 0**
- Training status: **BLOCKED_BEFORE_FIT**
- Test metric values: **none (not computed)**

The row audit and `model_dataset_preflight.json` list the exact blockers. Chevron–Noble is held from the full-feature table pending revenue-line harmonization; Amcor–Bemis is excluded under the US-listing-at-announcement and strict SEC-evidence requirements.

## What these changes do—and do not—mean

The changes materially improve **measurement, auditability, leakage control, and validation design**. They do not yet demonstrate improved numerical accuracy because there is no credible out-of-time test sample. The 100-observation rule is a project governance floor, not a guarantee of statistical power; we also need enough year coverage and payment-category support.

The model forecasts announced management claims conditional on deals that disclose a qualifying point estimate. It does not predict realized synergies, infer causality, determine if management is truthful, or determine premium fairness without the separate after-tax integration-cost and discounted-cash-flow bridge.

## Immediate next data priority

Expand the existing 88-deal master candidate ledger by filling (and independently checking) the exact announcement claim source, strict tax-basis quote, both pre-announcement SEC revenue filings, currency, US exchange listing at announcement, non-financial sector eligibility, and payment-source quote. Add observations only after all row-level fields pass; do not relax the rule or replace unknown values with assumptions merely to reach 100.

A curated expansion queue has also been created at `data/processed/model_data_expansion_queue_v2.csv`. It prioritizes the AstraZeneca–Alexion and R.H. Donnelley–Dex Media candidate leads, then Alcatel–Lucent and Quad–Worldcolor, while placing potential private-target and financial-sector candidates on hold. Every queue row is marked `HOLD_NOT_TRAINING_ROW`; listed amounts are discovery leads, not approved labels. The queue is not used by the model builder.
