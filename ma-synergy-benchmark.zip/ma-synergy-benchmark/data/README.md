# Data

All files in `processed/` are derived from public company announcements and SEC filings; every claim row carries its source URL.

| File | Rows | What it is |
|---|---|---|
| `MA_Synergy_Ledger_MASTER.csv` | 88 | Source ledger: announced synergy amount/range, type, tax basis, payment method, status, source URL |
| `MA_Synergy_Ledger_Curated_v2.csv` | 88 | MASTER plus cleaned flags (eligibility, claim form, tax basis, readiness, blockers, next action) and revenue where curated |
| `MA_Synergy_Ledger_COMPACT.csv` | 88 | Token-lean derived view (regenerate with `scripts/make_compact_ledger.py`) |
| `MA_Synergy_Data_Issue_Register_v2.csv` | 88 | Per-deal issues and next actions |
| `strict_verified_seed_observations.csv` | 6 | Source-reviewed seed rows with revenue, quotes, filing dates |
| `model_features_primary.csv` | 5 | Admitted rows (the only rows used for estimates) |
| `model_dataset_row_audit.csv` | 6 | Row-level scope/label/feature decisions and blocking flags |
| `model_data_expansion_queue_v2.csv` | 9 | Prioritized candidates for future admission (on hold, not used) |

Key conventions: money in **USD millions**; `*_pct` in **percentage points of target revenue**; dates ISO `YYYY-MM-DD`
(partial dates are scope-blocked); `payment_method_model` in {cash, stock, mixed}.
Known ledger issue: `MDT_COV` stores an "at least $850M" lower bound in the point column (see `docs/validation_v3.md`).
